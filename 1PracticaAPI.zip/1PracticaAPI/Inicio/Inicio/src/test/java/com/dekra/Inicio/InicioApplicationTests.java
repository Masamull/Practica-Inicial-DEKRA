package com.dekra.Inicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
